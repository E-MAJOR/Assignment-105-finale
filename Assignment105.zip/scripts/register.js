console.log("User Register");
// create constructor

/*
<input type="email" type="email" placeholder="Enter email" id="email">
            <input type="password" placeholder="password" id="password">
            <input type="firstname" type="text" placeholder="first name" id="firstName">
            <input type="lastname" type="text" placeholder="last name" id="lastName">
            <input type="address" placeholder="address" type="text" placeholder="address" id="address">
            <input type="phone" placeholder= "phone" type="tel" id="phone">
            <label>Payment</label>
            <select id="selPayment">
                <option>PayPal</option>
                <option>Cash</option>
                <option>Check</option>
                <option>Video Games</option>
            </select>
            <input type="color" placeholder="color" type="color" id="color">
            <div class="control">
                <label>Age</label>
                <input id="txtAge" type="number">
            </div>
*/
console.log("User register");
//create constructor
class User{
    constructor(email,pass,first,last,age,address,phone,payment,color='red'){
        //this.attr=parameter;
        this.email=email;
        this.password=pass;
        this.fname=first;
        this.lname=last;
        this.age=age;
        this.address=address;
        this.phone=phone;
        this.payment=payment;
        this.color=color;
    }
}


function isValid(user){
    // return false when the user is not valid
    // return true when the user is valid
    let valid = true;

    //We reset the original apperance all inputs
    //  by removing the error class (see style.css) 
    $('input').removeClass('error');
    

    if(user.fname.length == 0){
       //if we get here then the first name has not a valid value
       valid = false;
       //We add this error class (check css file) if the first name is not valid
       $("#txtFirst").addClass('error');
    }
    if(user.lname.length == 0){
        //is not a valid value
        $("#txtLast").addClass('error');
        valid = false;
    }
    if(user.password.length == 0){
        //is not a valid value
        $("#txtPassword").addClass('error');
        valid = false;
     }
     if(user.email.length == 0){
         //is not a valid value
         $("#txtEmail").addClass('error');
         valid = false;
    }

    return valid;
}



function registerUser(){
   let email = $("#txtEmail").val();//****check your id on the HTML
   let password = $("#txtPassword").val();
   let first=$("#txtFirst").val();
   let last = $("#txtLast").val();
   let age = $("#txtAge").val();
   let address = $("#txtAddress").val();
   let phone = $("#txtPhone").val();
   let payment = $("#selPayment").val();
   let color=$("#txtColor").val();
   let user=new User(email,password,first,last,age,address,phone,payment, color); //creating an instance
   if(isValid(user)){
       // $('#usersTable').append(createRow(user));
       console.log(user);
       saveUser(user); //function on storeManager.js
    }  
    clear();
}

function clear(){
    //to clear the input
   /* txtEmail.value='';
    txtPassword.value='';
    txtFirst.value='';
    txtLast.value='';
    txtAge.value=''; 
    txtAddress.value=''; 
    txtPhone.value='';
    selPayment.value='';
    console.log("cleared");*/
    $('#txtFirst').val("");
    $("#txtLast").val("");
    $("#txtAddress").val("");
    $("#txtPhone").val("");
    $("#selPayment").val("");
    $("#txtColor").val("");
    $("#txtEmail").val("");
    $("#txtPassword").val("");
    $("#txtAge").val("");
}

function init(){
    console.log("Init function");

}
window.onload=init;